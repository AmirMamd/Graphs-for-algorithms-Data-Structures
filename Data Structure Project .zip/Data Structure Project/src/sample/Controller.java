package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;

import java.io.IOException;
////////////////////////////////////////////////////////
import javafx.scene.control.TextField;

public class Controller {
    @FXML
    private Button viewOneSort;

    @FXML
    private Button compare;

    @FXML
    private RadioButton insertion;
    @FXML
    private RadioButton NlogN;

    @FXML
    private RadioButton nsquared;

    @FXML
    private RadioButton NplusK;

    @FXML
    private RadioButton NandK;

    @FXML
    private LineChart<String, Number> chartIndividual;
    @FXML
    private LineChart<String,Number> chartCompare;
    @FXML
    private RadioButton radix;

    @FXML
    private RadioButton heap;

    @FXML
    private RadioButton quick;

    @FXML
    private RadioButton counting;

    @FXML
    private RadioButton merge;
    @FXML
    private RadioButton selection;

    @FXML
    private RadioButton bubble;

    @FXML
    private TextField arrSize;
    @FXML
    private RadioButton N;


    @FXML
    private TextField Steps;
    @FXML
    private TextField ArraySize;

    @FXML
    private TextField S;
//    @FXML
//    void PressSelection(ActionEvent event) throws IOException {
//        chartIndividual.getData().clear();
//        int arr[] = new int[Integer.parseInt(ArraySize.getText())];
//        ReadNum s=new ReadNum();
//        int f[]=s.call();
//        Selection in =new Selection(f);
//        int e[]=in.getArrCount();
//        chartIndividual.getData().clear();
//        XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
//        for (int i = 0; i < arr.length; i+= Integer.parseInt(S.getText())) {
//            series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), e[i]));
//        }
//        series.setName("Selection Sort");
//        chartIndividual.getData().add(series);
//    }
//    @FXML
//    void PressBubble(ActionEvent event) throws IOException {
//        chartIndividual.getData().clear();
//        int arr[] = new int[Integer.parseInt(ArraySize.getText())];
//        ReadNum s=new ReadNum();
//        int f[]=s.call();
//        Bubble in =new Bubble(f);
//        int x[]=in.getArrCount();
//        chartIndividual.getData().clear();
//        XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
//        for (int i = 0; i < arr.length; i+= Integer.parseInt(S.getText())) {
//            series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
//        }
//        series.setName("Bubble Sort");
//        chartIndividual.getData().add(series);
//    }
//
//    @FXML
//    void PressCounting(ActionEvent event) throws IOException {
//        chartIndividual.getData().clear();
//        int arr[] = new int[Integer.parseInt(ArraySize.getText())];
//        ReadNum s=new ReadNum();
//        int f[]=s.call();
//        Counting in =new Counting(f);
//        int x[]=in.getArrCount();
//        XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
//        for (int i = 0; i < arr.length; i+= Integer.parseInt(S.getText())) {
//            series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
//        }
//        series.setName("Counting Sort");
//        chartIndividual.getData().add(series);
//    }
//
//    @FXML
//    void PressHeap(ActionEvent event) throws IOException {
//        chartIndividual.getData().clear();
//        int arr[] = new int[Integer.parseInt(ArraySize.getText())];
//        ReadNum s=new ReadNum();
//        int f[]=s.call();
//        Heap h =new Heap(f);
//        int x[]=h.getArrCount();
//        XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
//        for (int i = 0; i < arr.length; i+= Integer.parseInt(S.getText())) {
//            series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
//        }
//        series.setName("Heap Sort");
//        chartIndividual.getData().add(series);
//    }
//
//    @FXML
//    void PressInsertion(ActionEvent event) throws IOException {
//        chartIndividual.getData().clear();
//        int arr[] = new int[Integer.parseInt(ArraySize.getText())];
//            ReadNum s=new ReadNum();
//            int f[]=s.call();
//            Insertion in =new Insertion(f);
//            int x[]=in.getArrCount();
//            XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
//            for (int i = 0; i < arr.length; i+= Integer.parseInt(S.getText())) {
//                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
//            }
//            series.setName("Insertion Sort");
//            chartIndividual.getData().add(series);
//    }
//
//    @FXML
//    void PressMerge(ActionEvent event) throws IOException {
//        chartIndividual.getData().clear();
//        int arr[] = new int[Integer.parseInt(ArraySize.getText())];
//        ReadNum s=new ReadNum();
//        int f[]=s.call();
//        Merge m =new Merge(f);
//        int q[]=m.getArrCount();
//        XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
//        for (int i = 0; i < arr.length; i+= Integer.parseInt(S.getText())) {
//            series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), q[i]));
//        }
//        series.setName("Merge Sort");
//        chartIndividual.getData().add(series);
//    }
//
//    @FXML
//    void PressQuick(ActionEvent event) throws IOException {
//        chartIndividual.getData().clear();
//        int arr[] = new int[Integer.parseInt(ArraySize.getText())];
//        ReadNum s=new ReadNum();
//        int f[]=s.call();
//        Quick in =new Quick(f);
//        int x[]=in.getArrCount();
//        XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
//        for (int i = 0; i < arr.length; i+= Integer.parseInt(S.getText())) {
//            series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
//        }
//        series.setName("Quick Sort");
//        chartIndividual.getData().add(series);
//    }
//
//    @FXML
//    void PressRadix(ActionEvent event) throws IOException {
//        chartIndividual.getData().clear();
//        int arr[] = new int[Integer.parseInt(ArraySize.getText())];
//        ReadNum s=new ReadNum();
//        int f[]=s.call();
//        Radix in =new Radix(f);
//        int x[]=in.getArrCount();
//        XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
//        for (int i = 0; i < arr.length; i+= Integer.parseInt(S.getText())) {
//            series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
//        }
//        series.setName("Radix Sort");
//        chartIndividual.getData().add(series);
//    }

    public void Show(ActionEvent event) throws IOException {

        int arr[] = new int[Integer.parseInt(arrSize.getText())];
        if(insertion.isSelected())
        {

            ReadNum s=new ReadNum();
            int f[]=s.call();
            Insertion in =new Insertion(f);
            int x[]=in.getArrCount();
            XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
            for (int i = 0; i < arr.length; i+= Integer.parseInt(Steps.getText())) {
                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
            }
            series.setName("Insertion Sort");
            chartCompare.getData().add(series);
        }
         if (merge.isSelected())
        {

            ReadNum s=new ReadNum();
            int f[]=s.call();
            Merge m =new Merge(f);
            int q[]=m.getArrCount();
            XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
            for (int i = 0; i < arr.length; i+= Integer.parseInt(Steps.getText())) {
                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), q[i]));
            }
            series.setName("Merge Sort");
            chartCompare.getData().add(series);
        }
         if (quick.isSelected())
        {
            ReadNum r=new ReadNum();
            int m[]=r.call();
            Quick q =new Quick(m);
            int o[]=q.getArrCount();
            XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
            for (int i = 0; i < arr.length; i+= Integer.parseInt(Steps.getText())) {
                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), o[i]));
            }
            series.setName("Quick Sort");
            chartCompare.getData().add(series);
        }
        if (radix.isSelected())
        {
            ReadNum s=new ReadNum();
            int f[]=s.call();
            Radix in =new Radix(f);
            int x[]=in.getArrCount();
            XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
            for (int i = 0; i < arr.length; i+= Integer.parseInt(Steps.getText())) {
                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
            }
            series.setName("Radix Sort");
            chartCompare.getData().add(series);

        }
        if (counting.isSelected())
        {
            ReadNum s=new ReadNum();
            int f[]=s.call();
            Counting in =new Counting(f);
            int x[]=in.getArrCount();
            XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
            for (int i = 0; i < arr.length; i+= Integer.parseInt(Steps.getText())) {
                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
            }
            series.setName("Counting Sort");
            chartCompare.getData().add(series);
        }
         if (heap.isSelected())
        {
            ReadNum s=new ReadNum();
            int f[]=s.call();
            Heap h =new Heap(f);
            int x[]=h.getArrCount();
            XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
            for (int i = 0; i < arr.length; i+= Integer.parseInt(Steps.getText())) {
                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
            }
            series.setName("Heap Sort");
            chartCompare.getData().add(series);
        }
         if(selection.isSelected()){
             ReadNum s=new ReadNum();
             int f[]=s.call();
             Selection sel =new Selection(f);
             int x[]=sel.getArrCount();
             XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
             for (int i = 0; i < arr.length; i+= Integer.parseInt(Steps.getText())) {
                 series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
             }
             series.setName("Selection Sort");
             chartCompare.getData().add(series);
         }
         if (bubble.isSelected()){
             ReadNum s=new ReadNum();
             int f[]=s.call();
             Bubble b =new Bubble(f);
             int x[]=b.getArrCount();
             XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
             for (int i = 0; i < arr.length; i+= Integer.parseInt(Steps.getText())) {
                 series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
             }
             series.setName("Bubble Sort");
             chartCompare.getData().add(series);
         }
        if (nsquared.isSelected()){
            ReadNum s=new ReadNum();
            int f[]=s.call();
            Nsquared b =new Nsquared(f);
            int x[]=b.getArrCount();
            XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
            for (int i = 0; i < arr.length; i+= Integer.parseInt(Steps.getText())) {
                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
            }
            series.setName("Nsquared");
            chartCompare.getData().add(series);
        }
        if (NlogN.isSelected()){
            ReadNum s=new ReadNum();
            int f[]=s.call();
            nlogn b =new nlogn(f);
            double x[]=b.getArrCount();
            XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
            for (int i = 0; i < arr.length; i+= Integer.parseInt(Steps.getText())) {
                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
            }
            series.setName("Nlogn");
            chartCompare.getData().add(series);
        }
        if (NandK.isSelected()){
            ReadNum s=new ReadNum();
            int f[]=s.call();
            nandk b =new nandk(f);
            int x[]=b.getArrCount();
            XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
            for (int i = 0; i < arr.length; i+= Integer.parseInt(Steps.getText())) {
                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
            }
            series.setName("N*K");
            chartCompare.getData().add(series);
        }
        if (NplusK.isSelected()){
            ReadNum s=new ReadNum();
            int f[]=s.call();
            nplusk b =new nplusk(f);
            int x[]=b.getArrCount();
            XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
            for (int i = 0; i < arr.length; i+= Integer.parseInt(Steps.getText())) {
                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
            }
            series.setName("N+K");
            chartCompare.getData().add(series);
        }
        if (N.isSelected()){
            ReadNum s=new ReadNum();
            int f[]=s.call();
            n b =new n(f);
            int x[]=b.getArrCount();
            XYChart.Series<String,Number> series=new XYChart.Series<String,Number>();
            for (int i = 0; i < arr.length; i+= Integer.parseInt(Steps.getText())) {
                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(i), x[i]));
            }
            series.setName("N");
            chartCompare.getData().add(series);
        }
    }
    @FXML
    void Clear(ActionEvent event) {
    chartCompare.getData().clear();
    }
    @FXML
    void back(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("sample.fxml");
    }

    public void pressviewOneSort(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("test.fxml");
    }


    public void presscompare(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("compare.fxml");
    }
}