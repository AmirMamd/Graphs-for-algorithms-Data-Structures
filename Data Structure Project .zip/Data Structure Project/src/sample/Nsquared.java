package sample;

public class Nsquared {
    int count;
    int arrCount[];
    public Nsquared(int arr[]){
        arrCount = new int [arr.length];
        count = 0;
        for (int i = 0; i < arr.length ; i++){
            arrCount[i]= count * count;
            count++;
        }
    }
    public int [] getArrCount(){
        return arrCount;
    }
}
