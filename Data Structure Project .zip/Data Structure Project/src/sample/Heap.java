package sample;

public class Heap {
    int count;
    int arrCount[];

    public Heap(int arr[]) {
        int[] temp=arr;
        count=0;
        arrCount = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            count=0;
            heapSort(arr, i);
            arrCount[i] = count;
        }
    }

    void heapify(int arr[], int n, int i) {
        int largest = i;
        int l = 2 * i + 1;
        int r = 2 * i + 2;
        count += 3;
        if (l < n && arr[l] > arr[largest]) {
            largest = l;
            count++;
        }

        if (r < n && arr[r] > arr[largest]) {
            largest = r;
            count++;
        }

        if (largest != i) {
            int swap = arr[i];
            arr[i] = arr[largest];
            arr[largest] = swap;
            heapify(arr, n, largest);
            count += 3;
        }
    }

    void heapSort(int[] arr, int n) {
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(arr, n, i);
            count++;
        }
        for (int i = n - 1; i >= 0; i--) {

            int temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;
            count += 3;
            heapify(arr, i, 0);
        }
    }

    public int[] getArrCount() {
        return arrCount;
    }
}
