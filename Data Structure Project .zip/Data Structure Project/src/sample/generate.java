package sample;

import java.io.IOException;

public class generate {
    public static void main(String[] args) throws IOException {
        RandNum.GenerateNums(10000);
    }
}
