package sample;
import java.util.Arrays;

public class Radix {
    int count;
    int arrCount[];

    public Radix(int arr[]) {
        count = 0;
        int[] temp = arr;
        arrCount = new int [arr.length];
        for (int i = 0; i < arr.length; i++) {
            count = 0;
            radixsort(arr, i);
            arrCount[i] = count;
        }
    }

    int getMax(int arr[], int n)
        {
            int mx = arr[0];
            count++;
            for (int i = 1; i < n; i++)
                if (arr[i] > mx){
                    mx = arr[i];
                    count++;
                }
             return mx;
        }
        void countSort(int arr[], int n, int exp)
        {
            int output[] = new int[n];
            int i;
            int counter[] = new int[10];
            count+=3;
            Arrays.fill(counter, 0);
            for (i = 0; i < n; i++){
                counter[(arr[i] / exp) % 10]++;
                count++;
            }
            for (i = 1; i < 10; i++){
                counter[i] += counter[i - 1];
                count++;
            }
            for (i = n - 1; i >= 0; i--) {
                output[counter[(arr[i] / exp) % 10] - 1] = arr[i];
                counter[(arr[i] / exp) % 10]--;
                count+=2;
            }
            for (i = 0; i < n; i++)
                arr[i] = output[i];
            count++;
        }
        void radixsort(int arr[], int n)
        {
            int m = getMax(arr, n);
            count++;
            for (int exp = 1; m / exp > 0; exp *= 10){
                countSort(arr, n, exp);
                count++;
            }
        }
    public int []getArrCount(){
        return arrCount;
    }
}


