package sample;

public class Counting {
    int counter = 0;
    int arrCount[];

    public Counting(int arr[]) {
        counter = 0;
        arrCount = new int[arr.length];
        int[] temp = arr;
        for (int i = 0; i < arr.length; i++) {
            countSort(arr, i);
            arr=temp;
            arrCount[i] = counter;
            counter = 0;
        }
    }

        void countSort (int array[], int size){
            int[] output = new int[size + 1];
            counter++;
            int max = array[0];
            counter++;
            for (int i = 1; i < size; i++) {
                if (array[i] > max) {
                    max = array[i];
                    counter++;
                }
            }
            int[] count = new int[max + 1];
            for (int i = 0; i < max; ++i) {
                count[i] = 0;
                counter++;
            }
            for (int i = 0; i < size; i++) {
                count[array[i]]++;
                counter++;
            }
            for (int i = 1; i <= max; i++) {
                count[i] += count[i - 1];
                counter++;
            }
            for (int i = size - 1; i >= 0; i--) {
                output[count[array[i]] - 1] = array[i];
                count[array[i]]--;
                counter += 2;
            }
        }

    public int[] getArrCount() {
        return arrCount;
    }
}


