package sample;

public class nlogn {
    double count;
    double arrCount[];
    public nlogn(int arr[]){
        arrCount = new double [arr.length];
        count = 1;
        int n = arr.length;
        for (int i = 1; i < n ; i++){
            arrCount[i]= count *Math.log(count);
            count++;
        }
    }
    public double[] getArrCount(){
        return arrCount;
    }
}
