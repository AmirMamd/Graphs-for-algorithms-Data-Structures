package sample;

import javafx.scene.control.CheckBox;

import java.io.*;
import java.util.ArrayList;


public class ReadNum {
    public int[] call() throws IOException {
        File file = new File("src/rand.txt");
        BufferedReader b = new BufferedReader(new FileReader(file));

        String s;
        ArrayList<Integer> arr = new ArrayList<Integer>();
        int[] a;
        int i = 0;
        while ((s = b.readLine()) != null) {
            arr.add(Integer.parseInt(s));
        }
        a = new int[arr.size()];
        for (int j = 0; j < arr.size() - 1; j++) {
            a[j] = arr.get(j);
        }
        return a;
    }
}
