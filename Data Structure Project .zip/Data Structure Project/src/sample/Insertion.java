package sample;
public class Insertion  {
    private int count;
    public int arrCount[];
    public Insertion(int arr[])
    {
        arrCount = new int [arr.length];
        count  = 0;
        for (int i = 1; i < arr.length; i ++)
        {
            int key = arr[i];
            int j = i - 1;
            count += 2;
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j --;
                count+=2;
            }
            arr[j + 1] = key;
            count++;
            arrCount[i] = count;
        }
    }
    public int[] getArrCount()
    {
        return arrCount;
    }
}
