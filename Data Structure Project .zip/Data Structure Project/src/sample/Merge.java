package sample;

public class Merge {
    int count;
    int arrCount[];
public Merge(int arr[])
{
    count = 0;
    arrCount = new int [arr.length];
    int[] temp = arr;
    for(int i=0;i<arr.length;i++){
        sort(arr,0,i);
        arrCount[i] = count;
        count = 0;
    }
}
    void merge(int arr[], int l, int m, int r)
    {
        int n1 = m - l + 1;
        int n2 = r - m;

        int L[] = new int[n1];
        int R[] = new int[n2];
        count += 4;
        for (int i = 0; i < n1; ++i) {
            L[i] = arr[l + i];
            count++;
        }
        for (int j = 0; j < n2; ++j) {
            R[j] = arr[m + 1 + j];
            count++;
        }

        int i = 0, j = 0;
        int k = l;
        count++;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
                count +=2;
            }
            else {
                arr[k] = R[j];
                j++;
                count +=2;
            }
            k++;
            count++;
        }
        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
            count +=3;
        }
        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
            count +=3;
        }
    }
    void sort(int arr[], int l, int r)
    {
        if (l < r) {
            int m =l+ (r-l)/2;
            count++;
            sort(arr, l, m);
            sort(arr, m + 1, r);
            merge(arr, l, m, r);

        }
    }
    public int []getArrCount(){
    return arrCount;
    }
}
