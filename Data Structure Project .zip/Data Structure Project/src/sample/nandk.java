package sample;

import java.io.IOException;

public class nandk {
    int count;
    int arrCount[];
    public nandk(int arr[]) throws IOException {
        arrCount = new int [arr.length];
        count = 1;
        int n = arr.length;
        int k=0;

        ReadNum s=new ReadNum();

        int f[]=s.call();
        for (int i = 1; i < n ; i++){
            if (k<f[i]){
                k=f[i];
            }
        }
        for (int i = 1; i < n ; i++){
            arrCount[i]= count *k;
            count++;
        }
    }
    public int [] getArrCount(){
        return arrCount;
    }
}
