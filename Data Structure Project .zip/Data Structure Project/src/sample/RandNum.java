package sample;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;

public class RandNum {
    public static void  GenerateNums(int arrsize) throws IOException {
        File myFile = new File("src/rand.txt");
        Random rd = new Random();
        int arr[] = new int[arrsize];
        Scanner s = new Scanner(new File("src/rand.txt"));
        int[] array = new int[s.nextInt()];
    }

}
